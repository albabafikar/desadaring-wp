{if $wp->isWidgetAreaActive($wp->sidebar(right))}
<div id="secondary-right" class="sidebar-right-area" role="complementary">
		{sidebar $wp->sidebar(right)}
</div>
{/if}
