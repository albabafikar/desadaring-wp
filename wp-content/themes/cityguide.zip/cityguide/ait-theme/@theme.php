<?php

define('AIT_THEME_CODENAME', 'cityguide');
define('AIT_THEME_PACKAGE', 'premium');
