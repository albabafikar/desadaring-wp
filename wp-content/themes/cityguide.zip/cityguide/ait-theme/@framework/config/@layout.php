<?php

/**
 * This is buit-in config for @layout.neon config. These settings will be available always.
 * Settings in @layout.neon can be changed by theme developer according to the needs of the theme.
 */


return array(

);
