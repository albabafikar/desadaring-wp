<?php


return (object) array(

	'wp' => (object) array(
		'loginPageBranding' => true,
		'ogTags' => true,
	),

	'wpAdmin' => (object) array(
		'adminFooterText' => true,
	),
);
