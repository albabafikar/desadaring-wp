<?php

// comments_template filter expects path to template file,
// otherwise will output parent theme's comments.php or back compatibility file;
// solution is returning blank page
// sure it needs better solution but this is good enaugh solution for now
