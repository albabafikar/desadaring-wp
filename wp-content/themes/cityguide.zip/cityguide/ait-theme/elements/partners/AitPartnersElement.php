<?php


class AitPartnersElement extends AitElement
{
	public function getContentPreviewOptions()
	{
		return array(
			'layout' => 'box',
			'columns' => 5,
			'rows' => 1,
			'content' => false,
			'script' => false
		);
	}
}
