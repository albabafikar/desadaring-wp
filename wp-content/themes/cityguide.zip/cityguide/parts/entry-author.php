<span class="author vcard">
	<span class="auth-links">
		<a class="url fn n" href="{$post->author->postsUrl}" title="{__ 'View all posts by %s'|printf: $post->author}" rel="author">{$post->author}</a>
	</span>
</span>