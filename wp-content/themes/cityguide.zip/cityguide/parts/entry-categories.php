<span class="categories">

	<span class="cat-links">{!$post->categoryList(', ', '', $taxonomy)}</span>

</span>