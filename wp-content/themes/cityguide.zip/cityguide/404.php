{block content}

	{* template for page title is in parts/page-title.php *}

	<article id="post-0" class="post error404 no-results not-found">
		<div class="entry-content">
			<p>{__ "It seems we can't find what you're looking for."}</p>
		</div><!-- .entry-content -->
	</article><!-- #post-0 -->