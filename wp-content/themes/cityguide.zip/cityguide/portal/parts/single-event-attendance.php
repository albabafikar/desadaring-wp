{*if $meta->attendance*}
{*

<div class="attendance-container data-container">

	<h2 class="title">{__ 'Are you attending?'}</h2>

	<div class="content">
		<div class="attendance data">

		</div>
	</div>

</div>
*}





{*/if*}