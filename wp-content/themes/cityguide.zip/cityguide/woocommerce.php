{block content}

	{* template for page title is in parts/page-title.php *}

	<article class="content-block">
		<div class="entry-content">
			{? woocommerce_content() }
		</div><!-- .entry-content -->

	</article><!-- #post -->