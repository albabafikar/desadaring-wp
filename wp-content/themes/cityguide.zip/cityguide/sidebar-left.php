{if $wp->isWidgetAreaActive($wp->sidebar(left))}
<div id="secondary-left" class="sidebar-left-area" role="complementary">
	{sidebar $wp->sidebar(left)}
</div>
{/if}
